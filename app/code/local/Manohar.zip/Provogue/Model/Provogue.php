<?php
class Manohar_Provogue_Model_Provogue extends Mage_Core_Model_Abstract
{
	
}