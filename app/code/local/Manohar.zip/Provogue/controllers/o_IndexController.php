<?php
class Manohar_Provogue_IndexController extends Mage_Core_Controller_Front_Action
{
	public function IndexAction()
	{
		//echo 'block';
		$this->loadLayout();
		$this->renderLayout();

	}
}